import { create } from 'zustand';
import type { Election, User, Vote } from '../types';

interface Store {
  elections: Election[];
  currentUser: User | null;
  votes: Vote[];
  setCurrentUser: (user: User | null) => void;
  addVote: (vote: Vote) => void;
}

export const useStore = create<Store>((set) => ({
  elections: [
    {
      id: '1',
      title: 'Presidential Election 2024',
      description: 'National Presidential Election for 2024',
      startDate: new Date('2024-03-20'),
      endDate: new Date('2024-03-21'),
      candidates: [
        {
          id: '1',
          name: 'Alexandra Mitchell',
          party: 'Progressive Party',
          imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200&h=200'
        },
        {
          id: '2',
          name: 'Marcus Thompson',
          party: 'Conservative Alliance',
          imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200'
        }
      ]
    }
  ],
  currentUser: null,
  votes: [],
  setCurrentUser: (user) => set({ currentUser: user }),
  addVote: (vote) => set((state) => ({ 
    votes: [...state.votes, vote],
    currentUser: state.currentUser ? { ...state.currentUser, hasVoted: true } : null
  }))
}));