export interface Candidate {
  id: string;
  name: string;
  party: string;
  imageUrl: string;
}

export interface Election {
  id: string;
  title: string;
  description: string;
  startDate: Date;
  endDate: Date;
  candidates: Candidate[];
}

export interface Vote {
  electionId: string;
  candidateId: string;
  voterId: string;
  timestamp: Date;
}

export interface User {
  id: string;
  name: string;
  hasVoted: boolean;
}