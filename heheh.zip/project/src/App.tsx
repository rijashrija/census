import React from 'react';
import { Header } from './components/Header';
import { Login } from './components/Login';
import { VotingBooth } from './components/VotingBooth';
import { useStore } from './store/useStore';

function App() {
  const { currentUser } = useStore();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      {currentUser ? <VotingBooth /> : <Login />}
    </div>
  );
}

export default App;