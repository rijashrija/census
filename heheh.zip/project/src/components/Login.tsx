import React, { useState } from 'react';
import { UserCheck } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Login: React.FC = () => {
  const [voterId, setVoterId] = useState('');
  const { setCurrentUser } = useStore();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (voterId.trim()) {
      setCurrentUser({
        id: voterId,
        name: `Voter ${voterId}`,
        hasVoted: false
      });
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-xl shadow-xl w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-indigo-100 p-3 rounded-full mb-4">
            <UserCheck className="w-8 h-8 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Voter Authentication</h2>
          <p className="text-gray-600 text-center mt-2">
            Enter your voter ID to access the secure voting system
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label htmlFor="voterId" className="block text-sm font-medium text-gray-700">
              Voter ID
            </label>
            <input
              id="voterId"
              type="text"
              value={voterId}
              onChange={(e) => setVoterId(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Enter your voter ID"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Login to Vote
          </button>
        </form>
      </div>
    </div>
  );
};