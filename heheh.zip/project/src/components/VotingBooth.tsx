import React from 'react';
import { Check, AlertTriangle } from 'lucide-react';
import { useStore } from '../store/useStore';
import type { Candidate } from '../types';

export const VotingBooth: React.FC = () => {
  const { elections, currentUser, addVote } = useStore();
  const currentElection = elections[0];

  const handleVote = (candidate: Candidate) => {
    if (!currentUser) return;
    
    addVote({
      electionId: currentElection.id,
      candidateId: candidate.id,
      voterId: currentUser.id,
      timestamp: new Date()
    });
  };

  if (!currentUser) return null;

  if (currentUser.hasVoted) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center p-8 bg-green-50 rounded-lg">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
            <Check className="h-6 w-6 text-green-600" />
          </div>
          <h3 className="mt-2 text-sm font-medium text-green-800">Vote Recorded</h3>
          <p className="mt-1 text-sm text-green-700">
            Thank you for participating in the democratic process!
          </p>
        </div>
      </div>
    );
  }

  if (!currentElection) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center p-8 bg-yellow-50 rounded-lg">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100">
            <AlertTriangle className="h-6 w-6 text-yellow-600" />
          </div>
          <h3 className="mt-2 text-sm font-medium text-yellow-800">No Active Election</h3>
          <p className="mt-1 text-sm text-yellow-700">
            There are currently no active elections.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">{currentElection.title}</h2>
          <p className="mt-2 text-gray-600">{currentElection.description}</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {currentElection.candidates.map((candidate) => (
            <div
              key={candidate.id}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-center space-x-4">
                  <img
                    src={candidate.imageUrl}
                    alt={candidate.name}
                    className="h-16 w-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{candidate.name}</h3>
                    <p className="text-gray-600">{candidate.party}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleVote(candidate)}
                  className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
                >
                  Vote for {candidate.name}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};